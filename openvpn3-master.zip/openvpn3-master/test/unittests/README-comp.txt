To test and compare speed of the decomrpession algorithms define N_EXPAND to be more than 1 by either edition
the test-comp.c or by add a -DN_EXPAND=1000 or -DN_COMPRESS=1000 for the compression speed in the CmakeLists
and looks at the time the unit test take for the different combinations.
